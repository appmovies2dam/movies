var Miplugin = (function(){

	var Miplugin = {};

	function ensureBoolean(callback){
		return function(result){
			callback(!!result);
		}
	}

	Miplugin.appNativa = function(url) {
		return cordova.exec(null,
			null,
			'Miplugin',
			'appNativa',
			[url]);
	};

	return Miplugin;
});

module.exports = new Miplugin();
