cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/cordova-plugin-geolocation/www/android/geolocation.js",
        "id": "cordova-plugin-geolocation.geolocation",
        "clobbers": [
            "navigator.geolocation"
        ]
    },
    {
        "file": "plugins/cordova-plugin-geolocation/www/PositionError.js",
        "id": "cordova-plugin-geolocation.PositionError",
        "runs": true
    },
    {
        "file": "plugins/cordova.plugins.diagnostic.api-22/www/android/diagnostic.js",
        "id": "cordova.plugins.diagnostic.api-22.Diagnostic",
        "clobbers": [
            "cordova.plugins.diagnostic"
        ]
    },
    {
        "file": "plugins/cordova.plugins.miplugin/www/android/miplugin.js",
        "id": "cordova.plugins.miplugin.Miplugin",
        "clobbers": [
            "cordova.plugins.miplugin"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-compat": "1.0.0",
    "cordova-plugin-geolocation": "2.2.0",
    "cordova.plugins.diagnostic.api-22": "2.3.10-api-22",
    "cordova-plugin-whitelist": "1.2.3-dev",
    "cordova.plugins.miplugin": "1.0.0"
};
// BOTTOM OF METADATA
});