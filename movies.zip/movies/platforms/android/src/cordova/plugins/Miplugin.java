package cordova.plugins;

import org.apache.cordova.CordovaWebView;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaInterface;
import org.json.JSONArray;
import org.json.JSONException;

import android.net.Uri;

import android.content.Context;
import android.content.Intent;


public class Miplugin extends CordovaPlugin{

    protected CallbackContext currentContext;

    public Miplugin() {}

    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        super.initialize(cordova, webView);
    }

    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        currentContext = callbackContext;

        try {
            if (action.equals("appNativa")){
                appNativa(args.getString(0));
                callbackContext.success();
            } else {
                handleError("Invalid action");
                return false;
            }
        }catch(Exception e ) {
            handleError("Exception occurred: ".concat(e.getMessage()));
            return false;
        }
        return true;
    }
	
	public void appNativa(String url) {
		Intent settingsIntent=new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        cordova.getActivity().startActivity(settingsIntent);
    }

    private void handleError(String errorMsg, CallbackContext context){
        try {
            context.error(errorMsg);
        } catch (Exception e) {
        }
    }

    private void handleError(String errorMsg){
        handleError(errorMsg, currentContext);
    }
}
